import React, { Component } from "react";
import classes from "./Models.module.css";
import Header from "../../UI/Navbar/Header";
import MyDrawer from "./Drawer/Drawer";
import { Switch, Route, Link, Redirect } from "react-router-dom";
import LiveGraph from "../LiveGraph/LiveGraph";
import CasesGraph from "../CasesGraph/CasesGraph";
import Gallery from "../Gallery/Gallery";
import Temperature from "../Temperature/Temperature";

class Models extends Component {
  render() {
    return (
      <>
        <Header page="models" user={this.props.user} />
        {this.props.user ? (
          <div style={{ marginTop: "80px" }}>
            <MyDrawer>
              <div className="mt-3">
                <Link to="/dashboard/live_demo">
                  <div className={classes.drawerLink}>Violation Detector</div>
                </Link>
                {/* <Link to="/dashboard/case_predictor">
                  <div className={classes.drawerLink}>Case Predictor</div>
                </Link> */}
                <Link to="/dashboard/gallery">
                  <div className={classes.drawerLink}>Gallery</div>
                </Link>
                <Link to="/dashboard/temperature">
                  <div className={classes.drawerLink}>Temperature Data</div>
                </Link>
              </div>
            </MyDrawer>
            <div style={{ marginLeft: "250px" }}>
              <div className="container-fluid">
                <Switch>
                  <Route exact path="/">
                    <Redirect to="/dashboard/gallery" />
                  </Route>
                  <Route
                    exact
                    path="/dashboard/case_predictor"
                    component={CasesGraph}
                  />
                  <Route
                    exact
                    path="/dashboard/live_demo"
                    component={LiveGraph}
                  />
                  <Route
                    exact
                    path="/dashboard/temperature"
                    component={Temperature}
                  />
                  <Route exact path="/dashboard/gallery" component={Gallery} />
                </Switch>
              </div>
            </div>
          </div>
        ) : null}
      </>
    );
  }
}

export default Models;
