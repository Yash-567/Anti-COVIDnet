// import firebase from "firebase/app";
// import "firebase/auth";
// import "firebase/firestore";

// var firebaseConfig = {
//   apiKey: "AIzaSyD_6zJQS_1CO8ppsm3RNxGMfnDsc8Uezxw",
//   authDomain: "anti-covidnet-auth.firebaseapp.com",
//   databaseURL: "https://anti-covidnet-auth.firebaseio.com",
//   projectId: "anti-covidnet-auth",
//   storageBucket: "anti-covidnet-auth.appspot.com",
//   messagingSenderId: "758946563240",
//   appId: "1:758946563240:web:1f8afeef90a176d909ee9d",
//   measurementId: "G-YTLXW25L3C",
// };

// const fire = firebase.initializeApp(firebaseConfig);
// export default fire;

// /* logout(){
//     fire.auth().signOut();
// } */
