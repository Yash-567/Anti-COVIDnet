export const tempdata = [
  { name: "Student Student ", temperature: "37.5", id: "C2K18644579" },
  { name: "Student Student", temperature: "37.5", id: "C2K18644579" },
  { name: "Student Student", temperature: "37.5", id: "C2K18644579" },
  { name: "Student Student", temperature: "37.5", id: "C2K18644579" },
  { name: "Student Student", temperature: "37.5", id: "C2K18644579" },
  { name: "Student Student", temperature: "37.5", id: "C2K18644579" },
  { name: "Student Student", temperature: "37.5", id: "C2K18644579" },
  { name: "Student Student", temperature: "37.5", id: "C2K18644579" },
];
